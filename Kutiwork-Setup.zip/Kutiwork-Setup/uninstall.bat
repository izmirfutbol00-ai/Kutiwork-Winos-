@echo off
setlocal
title Kutiwork Kaldir
echo.
echo  Kutiwork kaldiriliyor...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item ([Environment]::GetFolderPath('Desktop')+'\Kutiwork.lnk'),([Environment]::GetFolderPath('Programs')+'\Kutiwork.lnk') -ErrorAction SilentlyContinue"
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Kutiwork" /f >nul 2>&1
echo  Kaldirildi.
start "" /min cmd /c "ping 127.0.0.1 -n 3 >nul & rmdir /s /q ""%~dp0"""
exit /b 0
