@echo off
setlocal
cd /d "%~dp0"
title Kutiwork Setup.exe olustur
set "SED=%TEMP%\kutiwork.sed"
>"%SED%"  echo [Version]
>>"%SED%" echo Class=IEXPRESS
>>"%SED%" echo SEDVersion=3
>>"%SED%" echo [Options]
>>"%SED%" echo PackagePurpose=InstallApp
>>"%SED%" echo ShowInstallProgramWindow=1
>>"%SED%" echo HideExtractAnimation=1
>>"%SED%" echo UseLongFileName=1
>>"%SED%" echo InsideCompressed=0
>>"%SED%" echo CAB_FixedSize=0
>>"%SED%" echo CAB_ResvCodeSigning=0
>>"%SED%" echo RebootMode=N
>>"%SED%" echo InstallPrompt=%%InstallPrompt%%
>>"%SED%" echo DisplayLicense=%%DisplayLicense%%
>>"%SED%" echo FinishMessage=%%FinishMessage%%
>>"%SED%" echo TargetName=%%TargetName%%
>>"%SED%" echo FriendlyName=%%FriendlyName%%
>>"%SED%" echo AppLaunched=%%AppLaunched%%
>>"%SED%" echo PostInstallCmd=%%PostInstallCmd%%
>>"%SED%" echo AdminQuietInstCmd=%%AdminQuietInstCmd%%
>>"%SED%" echo UserQuietInstCmd=%%UserQuietInstCmd%%
>>"%SED%" echo SourceFiles=SourceFiles
>>"%SED%" echo [Strings]
>>"%SED%" echo InstallPrompt=Kutiwork kurulsun mu?
>>"%SED%" echo DisplayLicense=
>>"%SED%" echo FinishMessage=Kutiwork kuruldu.
>>"%SED%" echo TargetName=%~dp0Kutiwork-Setup.exe
>>"%SED%" echo FriendlyName=Kutiwork Kurulum
>>"%SED%" echo AppLaunched=cmd /c install.bat
>>"%SED%" echo PostInstallCmd=^<None^>
>>"%SED%" echo AdminQuietInstCmd=
>>"%SED%" echo UserQuietInstCmd=
>>"%SED%" echo FILE0="kutiwork.html"
>>"%SED%" echo FILE1="install.bat"
>>"%SED%" echo FILE2="shortcut.ps1"
>>"%SED%" echo FILE3="uninstall.bat"
>>"%SED%" echo [SourceFiles]
>>"%SED%" echo SourceFiles0=%~dp0
>>"%SED%" echo [SourceFiles0]
>>"%SED%" echo %%FILE0%%=
>>"%SED%" echo %%FILE1%%=
>>"%SED%" echo %%FILE2%%=
>>"%SED%" echo %%FILE3%%=

echo.
echo  Kutiwork-Setup.exe olusturuluyor...
iexpress /N /Q "%SED%"
if exist "%~dp0Kutiwork-Setup.exe" (
  echo  Hazir: %~dp0Kutiwork-Setup.exe
) else (
  echo  Olusturulamadi. IExpress ile elle de olusturabilirsiniz: iexpress.exe
)
pause
