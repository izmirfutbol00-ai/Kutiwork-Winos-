@echo off
setlocal
title Kutiwork Kurulum
set "DEST=%LOCALAPPDATA%\Kutiwork"
echo.
echo  Kutiwork kuruluyor...
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0kutiwork.html" "%DEST%\kutiwork.html" >nul
if errorlevel 1 goto hata
copy /Y "%~dp0uninstall.bat" "%DEST%\uninstall.bat" >nul

set "BR="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BR=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BR if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BR=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BR if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BR=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BR if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BR=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BR if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "BR=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0shortcut.ps1" -Target "%BR%" -Html "%DEST%\kutiwork.html"

set "RK=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Kutiwork"
reg add "%RK%" /v DisplayName /d "Kutiwork" /f >nul
reg add "%RK%" /v Publisher /d "Kutiwork" /f >nul
reg add "%RK%" /v DisplayVersion /d "1.0" /f >nul
reg add "%RK%" /v InstallLocation /d "%DEST%" /f >nul
reg add "%RK%" /v UninstallString /d "\"%DEST%\uninstall.bat\"" /f >nul
reg add "%RK%" /v NoModify /t REG_DWORD /d 1 /f >nul
reg add "%RK%" /v NoRepair /t REG_DWORD /d 1 /f >nul

echo.
echo  Kurulum tamamlandi. Masaustunde ve Baslat menusunde Kutiwork kisayolu var.
start "" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Kutiwork.lnk"
timeout /t 3 >nul
exit /b 0

:hata
echo.
echo  Hata: dosyalar kopyalanamadi. Kurulum iptal edildi.
pause
exit /b 1
