param([string]$Target,[string]$Html)
$url = ([Uri]$Html).AbsoluteUri
$w = New-Object -ComObject WScript.Shell
if ($Target) { $arg = '--app=' + $url; $icon = $Target + ',0' }
else { $Target = $Html; $arg = ''; $icon = '' }
foreach ($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $l = $w.CreateShortcut((Join-Path $d 'Kutiwork.lnk'))
  $l.TargetPath = $Target
  if ($arg) { $l.Arguments = $arg }
  if ($icon) { $l.IconLocation = $icon }
  $l.Description = 'Kutiwork'
  $l.Save()
}
